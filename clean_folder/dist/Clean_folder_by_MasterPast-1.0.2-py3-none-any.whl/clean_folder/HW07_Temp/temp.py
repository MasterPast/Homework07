def pri(s,q, ):
    print(s,'!!!', q[w[0]])

