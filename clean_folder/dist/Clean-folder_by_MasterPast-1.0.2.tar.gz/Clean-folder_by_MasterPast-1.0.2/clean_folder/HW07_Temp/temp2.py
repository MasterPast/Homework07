from temp import pri

q=40
pri(3,q)